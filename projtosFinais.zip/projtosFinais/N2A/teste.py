a = 10
b = 2

Z = a+b
print(Z)